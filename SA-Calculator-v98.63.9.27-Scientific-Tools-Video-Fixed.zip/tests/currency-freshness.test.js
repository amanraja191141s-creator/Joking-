const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const ROOT = path.resolve(__dirname, '..');
const source = fs.readFileSync(path.join(ROOT, 'assets/js/app.js'), 'utf8');
function extract(name) {
  const start = source.indexOf(`function ${name}(`);
  assert.notEqual(start, -1, `${name} not found`);
  const open = source.indexOf('{', start); let depth = 0;
  for (let i = open; i < source.length; i++) {
    if (source[i] === '{') depth++;
    else if (source[i] === '}' && --depth === 0) return source.slice(start, i + 1);
  }
  throw new Error(`Could not extract ${name}`);
}
const today = () => new Date().toISOString().slice(0, 10);
const daysAgo = n => new Date(Date.now() - n * 86400000).toISOString().slice(0, 10);
const code = i => `C${String.fromCharCode(65 + Math.floor(i / 26))}${String.fromCharCode(65 + (i % 26))}`;

test('currency cache revalidates every currency observation date independently', () => {
  const rates = Object.fromEntries(Array.from({length:12}, (_,i)=>[code(i), i+1]));
  const rateDates = Object.fromEntries(Object.keys(rates).map(k=>[k,today()]));
  rateDates.CAA = daysAgo(20); // stale pair must be dropped even if aggregate date is fresh
  const store = JSON.stringify({savedAt:Date.now(),rates,rateDate:today(),rateDates,source:'Frankfurter v2'});
  const context = {
    Date, Number, String, Object, JSON, Error,
    CURRENCY_RATE_CACHE_KEY:'cache', CURRENCY_RATE_CACHE_MAX_AGE:7*86400000,
    BUILTIN_CURRENCY_RATES:{USD:1,INR:90},
    STATE:{}, localStorage:{getItem:()=>store}, setRuntimeCurrencyNames:()=>{}
  };
  vm.runInNewContext(`${extract('validateCurrencyRateDate')};${extract('loadCachedCurrencyRates')};globalThis.load=loadCachedCurrencyRates;`, context);
  assert.equal(context.load(), true);
  assert.equal(context.STATE.currencies.CAA, undefined);
  assert.equal(Object.keys(context.STATE.currencies).length, 11);
  assert.equal(context.STATE.currencyRateDates.CAB, today());
});

test('cache with missing or undated currency rows never revives those rates', () => {
  const rates = Object.fromEntries(Array.from({length:12}, (_,i)=>[code(i), i+1]));
  const rateDates = Object.fromEntries(Object.keys(rates).map(k=>[k,today()]));
  delete rateDates.CAA;
  const store = JSON.stringify({savedAt:Date.now(),rates,rateDate:today(),rateDates,source:'test'});
  const context = {Date,Number,String,Object,JSON,Error,CURRENCY_RATE_CACHE_KEY:'cache',CURRENCY_RATE_CACHE_MAX_AGE:7*86400000,BUILTIN_CURRENCY_RATES:{USD:1,INR:90},STATE:{},localStorage:{getItem:()=>store},setRuntimeCurrencyNames:()=>{}};
  vm.runInNewContext(`${extract('validateCurrencyRateDate')};${extract('loadCachedCurrencyRates')};globalThis.load=loadCachedCurrencyRates;`,context);
  assert.equal(context.load(),true);
  assert.equal(context.STATE.currencies.CAA,undefined);
});

test('currency decimal math preserves large amounts and bounded division precision', () => {
  const context = {String, Number, BigInt, Math};
  vm.runInNewContext(`${extract('decimalParts')};${extract('decimalMultiply')};${extract('decimalDivide')};globalThis.mul=decimalMultiply;globalThis.div=decimalDivide;`, context);
  assert.equal(context.mul('123456789012345.67', '1.2345'), '152407406035740.729615');
  assert.equal(context.div('100', '3', 8), '33.33333333');
  assert.equal(context.div('1', '0', 8), null);
});

test('cross-currency pair math uses the USD-base rate ratio in both directions', () => {
  const context = { BigInt, Number, String, Math };
  vm.runInNewContext(`${extract('decimalParts')};${extract('decimalMultiply')};${extract('decimalDivide')};globalThis.mul=decimalMultiply;globalThis.div=decimalDivide;`, context);
  const eurToInrRate = context.div('83', '0.92', 12);
  const inrToEurRate = context.div('0.92', '83', 12);
  assert.equal(context.mul('10', eurToInrRate), '902.17391304348');
  assert.equal(context.mul('1000', inrToEurRate), '11.084337349');
  assert.equal(context.mul('25', '1'), '25');
});

test('late older provider observations cannot overwrite newer per-currency rates', () => {
  const context = { Date, Number, String, Object, Error };
  vm.runInNewContext(`${extract('validateCurrencyRateDate')};${extract('mergeCurrencyRateBundles')};globalThis.merge=mergeCurrencyRateBundles;`, context);
  const current = { USD: 1, INR: 83, EUR: 0.92 };
  const dates = { USD: today(), INR: today(), EUR: daysAgo(1) };
  const incoming = { USD: 1, INR: 82, EUR: 0.93, GBP: 0.79 };
  const incomingDates = { USD: today(), INR: daysAgo(1), EUR: today(), GBP: today() };
  const merged = context.merge(current, dates, incoming, incomingDates);
  assert.equal(merged.rates.INR, 83, 'older INR observation must not roll back');
  assert.equal(merged.rates.EUR, 0.93, 'newer EUR observation should be accepted');
  assert.equal(merged.rates.GBP, 0.79, 'new supported currency should be added');
  assert.equal(merged.accepted, 3);
  assert.deepEqual(Array.from(merged.acceptedCodes).sort(), ['EUR', 'GBP', 'USD']);
});

test('same-date fallback observations cannot silently replace the selected primary provider', () => {
  const context = { Date, Number, String, Object, Error };
  vm.runInNewContext(`${extract('validateCurrencyRateDate')};${extract('mergeCurrencyRateBundles')};globalThis.merge=mergeCurrencyRateBundles;`, context);
  const date = today();
  const merged = context.merge({ USD: 1, INR: 83 }, { USD: date, INR: date }, { USD: 1, INR: 82 }, { USD: date, INR: date }, { USD: 'USD base', INR: 'Fawaz Exchange API' }, { USD: 'USD base', INR: 'Open ER-API' });
  assert.equal(merged.rates.INR, 83);
  assert.equal(merged.acceptedCodes.includes('INR'), false);
  const sameProvider = context.merge({ USD: 1, INR: 83 }, { USD: date, INR: date }, { USD: 1, INR: 83.1 }, { USD: date, INR: date }, { USD: 'USD base', INR: 'Fawaz Exchange API' }, { USD: 'USD base', INR: 'Fawaz Exchange API' });
  assert.equal(sameProvider.rates.INR, 83.1, 'same provider may correct a same-day observation');
});

test('selected pair uses the older of its two observation dates', () => {
  const context = { String };
  vm.runInNewContext(`${extract('getCurrencyPairObservationDate')};globalThis.pairDate=getCurrencyPairObservationDate;`, context);
  assert.equal(context.pairDate('USD', 'INR', { USD: today(), INR: daysAgo(2) }), daysAgo(2));
  assert.equal(context.pairDate('USD', 'USD', { USD: today() }), null, 'same-currency conversion does not need an FX observation date');
  assert.equal(context.pairDate('USD', 'EUR', { USD: today() }, daysAgo(3)), null, 'do not imply a pair date when one observation date is missing');
});

test('Retry-After parser supports seconds and HTTP dates with a bounded delay', () => {
  const context = { Date, String, Number, Math };
  vm.runInNewContext(`${extract('parseRetryAfter')};globalThis.parse=parseRetryAfter;`, context);
  assert.equal(context.parse('12', 0), 12000);
  assert.equal(context.parse('invalid', 0), 0);
  assert.equal(context.parse('999999', 0), 86400000);
});


test('currency display uses ISO minor units and rounds half-up while preserving decimal math', () => {
  const context = {String, Number, BigInt, Intl, STATE:{thousandsSep:'comma'}};
  vm.runInNewContext(`${extract('decimalParts')};${extract('formatCurrencyExact')};globalThis.format=formatCurrencyExact;`, context);
  assert.equal(context.format('1234.565', 'USD'), '1,234.57');
  assert.equal(context.format('1234.5', 'JPY'), '1,235');
  assert.equal(context.format('1.2345', 'KWD'), '1.235');
  assert.equal(context.format('-0.005', 'USD'), '-0.01');
  context.STATE.thousandsSep='space'; assert.equal(context.format('1234567.89','USD'),'1 234 567.89');
  context.STATE.thousandsSep='lakh'; assert.equal(context.format('12345678.9','INR'),'1,23,45,678.90');
  context.STATE.thousandsSep='none'; assert.equal(context.format('1234567.89','USD'),'1234567.89');
});

test('Frankfurter provider provenance is retained per currency and excludes non-currency units', () => {
  const rows = Array.from({length:24}, (_,i)=>({base:'USD',quote:code(i),rate:i+1,date:today(),providers:['ecb','ust']}));
  rows.push({base:'USD',quote:'XAU',rate:1,date:today(),providers:['test']});
  const context = {Date,Number,String,Object,Array,Error,NON_CURRENCY_CODES:new Set(['XAU'])};
  vm.runInNewContext(`${extract('validateCurrencyRateDate')};${extract('normalizeFrankfurterV2Rates')};globalThis.normalize=normalizeFrankfurterV2Rates;`,context);
  const result=context.normalize(rows);
  assert.equal(result.rates.XAU,undefined);
  assert.equal(result.rateSources.CAA,'Frankfurter v2');
  assert.doesNotMatch(JSON.stringify(result.rateSources), /\[object Object\]/);
  assert.equal(result.rateSources.USD,'USD base');
});

test('USD pair date uses quote observation date and never an unrelated aggregate date', () => {
  const context={String};
  vm.runInNewContext(`${extract('getCurrencyPairObservationDate')};globalThis.pair=getCurrencyPairObservationDate;`,context);
  assert.equal(context.pair('USD','INR',{USD:today(),INR:daysAgo(2)},today()),daysAgo(2));
  assert.equal(context.pair('EUR','USD',{EUR:daysAgo(3),USD:today()}),daysAgo(3));
});

test('currency observation age helper identifies older reference dates without changing exact dates', () => {
  const context = { Date, String, Math };
  vm.runInNewContext(`${extract('currencyObservationAgeDays')};globalThis.age=currencyObservationAgeDays;`, context);
  assert.equal(context.age(today()), 0);
  assert.equal(context.age(daysAgo(4)), 4);
  assert.equal(context.age('not-a-date'), null);
});

test('active ISO catalogue excludes known retired codes and fund/metal codes', () => {
  const app=fs.readFileSync(path.join(ROOT,'assets/js/app.js'),'utf8');
  const match=app.match(/const NON_CURRENCY_CODES = new Set\(\[(.*?)\]\);/);
  assert.ok(match);
  for(const retired of ['ANG','BGN','BGL','BRE','BRR','BYR','CUC','EEK','HRK','LTL','LVL','MRO','MZM','ROL','RUR','SLL','SVC','STD','TMM','TRL','VEB','VEF','ZMK','ZWD','ZWN','ZWR','ZWL','AON','AOR','AZM']) assert.ok(match[1].includes(`'${retired}'`));
  assert.match(app, /\"XCG\": \"Caribbean Guilder\"/);
  for(const fund of ['BOV','CHE','CHW','CLF','XAU','XAG','XDR']) assert.ok(match[1].includes(`'${fund}'`));
});


test('public global providers are checked in primary/fallback order with date-aware merging', () => {
  const pipeline = source.slice(source.indexOf('async function fetchCurrencyRateBundle('), source.indexOf('function getCurrencyPairSources('));
  assert.match(pipeline, /name:'Frankfurter v2'[\s\S]*name:'Open ER-API'[\s\S]*name:'Fawaz Exchange API'/);
  assert.doesNotMatch(pipeline, /SA_CURRENCY_API_URL|xurrency|XCURRENCY/i);
  assert.doesNotMatch(source, /normalizePrivateSaCurrencyRates|normalizeXurrencyRates|isXurrencyProxyEnabled/);
  assert.match(pipeline, /const missing = \(\) => requiredCodes\.filter/);
  assert.match(pipeline, /combined\.missingRequired=missing\(\)/);
  assert.match(pipeline, /Multi-source reference rates/);
});


test('partial selected-pair responses schedule bounded retry and pair changes trigger a fresh lookup', () => {
  assert.match(source, /if \(missingRequired\.length\) \{/);
  assert.match(source, /\(retry scheduled\)/);
  assert.match(source, /selectedPair\.some\(\(code,index\)=>code!==requestedPair\[index\]\)/);
  assert.match(source, /if \(!STATE\.currencies\?\.\[fromSel\.value\] \|\| !STATE\.currencies\?\.\[toSel\.value\]\) refreshCurrencyRates\(false\)/);
  assert.match(source, /!currencyRetryTimer && \(currencyRetryDelay > 0/);
});

test('currency amount reset clears derived raw metadata and derived writes stay synchronized', () => {
  const attrs = new Map([['data-derived', 'true']]);
  const span = { textContent: '' };
  const el = {
    dataset: { currencyRaw: '123.456', currencyDerived: 'true' },
    getAttribute: key => attrs.get(key) ?? null,
    setAttribute: (key, value) => attrs.set(key, value),
    removeAttribute: key => attrs.delete(key),
    querySelector: () => span
  };
  const context = { String, document: { getElementById: () => el } };
  vm.runInNewContext(`${extract('setCurrencyAmountRaw')};globalThis.set=setCurrencyAmountRaw;`, context);
  context.set('cur-amount', '5', false);
  assert.equal(el.getAttribute('data-derived'), null);
  assert.equal(el.dataset.currencyRaw, undefined);
  assert.equal(span.textContent, '5');
  context.set('cur-amount', '5.1234', true);
  assert.equal(el.getAttribute('data-derived'), 'true');
  assert.equal(el.dataset.currencyRaw, '5.1234');
});

test('currency swap handler declares its source field and cannot reference a calc-local variable', () => {
  const start = source.indexOf("swapBtn?.addEventListener('click'");
  const end = source.indexOf("document.getElementById('btn-refresh-rates')", start);
  const handler = source.slice(start, end);
  assert.match(handler, /fromEl=document\.getElementById\('cur-amount'\)/);
  assert.match(handler, /toEl=document\.getElementById\('cur-to-amount'\)/);
  assert.match(handler, /if\(!from\|\|!to\|\|!fromEl\|\|!toEl\) return/);
});
