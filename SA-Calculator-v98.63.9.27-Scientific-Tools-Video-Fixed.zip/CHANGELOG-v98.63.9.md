# SA Calculator v98.63.9 — Clean runtime consolidation

- Removed the old CSS source-layer build pipeline that re-concatenated 25 historical stylesheet files on every Android web build.
- Replaced it with one canonical production stylesheet: `assets/css/app.css`.
- Removed obsolete `app-base.css` and `rebuild-v98.*.css` source files from the project and production package.
- Safely removed 2,272 repeated declarations where selector, property, value, importance, and at-rule context were identical; retained differing declarations and cascade order.
- Removed 233 empty CSS rules and one empty at-rule left by historical overrides.
- Updated the Android web builder, service-worker cache namespace, app version, manifest, workflow, and regression tests.
- Android `www/assets/css/` now contains only `app.css`.
- Existing calculator, converter, tools, history, favorites, and settings JavaScript runtime was retained; no unverified runtime functions were deleted.
