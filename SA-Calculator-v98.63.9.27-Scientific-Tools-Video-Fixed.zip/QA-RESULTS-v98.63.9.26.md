# QA Results — v98.63.9.26

- Release regression suite: **60/60 pass** (see included `npm test`).
- JavaScript syntax: pass (`node --check assets/js/app.js`).
- Android web bundle: pass (`npm run build:web`, 13 required assets).
- Workflow YAML parse: pass.
- HTML tool destinations and inventory: 19 calculator/tool destinations plus core/settings surfaces, no missing IDs in the current test gate.
- Salary representative case: monthly gross ₹1,000 with 20% deductions yields ₹800 monthly / ₹9,600 annual net.
- SIP representative case: ₹500/month, 12% annual return, 1 year uses monthly compounding and yields a checked projected result.
- Inverse-hyperbolic scalar functions: representative numerical values tested.
- Complex-number calculation: intentionally unsupported.
- Physical Android APK build, touch responsiveness, screen-size parity, offline transition and OEM gestures: **not verified**.
- Historical `npm run test:legacy` corpus: **368 passed / 76 failed**. Most assertions are pinned to earlier versions/layouts; this is diagnostic and not the release gate.
