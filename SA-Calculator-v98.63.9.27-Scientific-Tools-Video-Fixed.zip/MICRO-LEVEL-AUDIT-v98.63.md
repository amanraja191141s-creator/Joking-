# Micro-level cleanup audit — v98.63

## Findings and changes

1. **Stale release documents:** the root contained more than 100 accumulated historical notes, audits, research summaries and QA reports. These were not runtime app screens. Removed old copies and retained the current README, changelog, audit, QA and limitations files.
2. **Duplicate workflows:** multiple old versioned workflow YAML files were shipped alongside the canonical workflow. Removed duplicate copies; `.github/workflows/main.yml` is canonical.
3. **Unused design assets:** removed obsolete visual mockups and an old inventory not used by the runtime or regression tests.
4. **Promotional header copy:** removed “SMART • POWERFUL • PREMIUM” and simplified the browser/document title. The app name remains “SA Calculator”.
5. **History action wording:** retained “Clear Unlocked History” because the action deliberately preserves protected entries; this label accurately describes its behavior.
6. **Release identity:** synchronized package, manifest, HTML, runtime, service worker and workflow to `1.98.65-v98.63.9.17`, Android versionCode `1098065`.

## Preserved

- Calculator and scientific calculator screens and calculation engine.
- History and favorites.
- Tools, unit converters and currency converter.
- Settings, theme controls, localization and accessibility labels.
- Capacitor Android build configuration and source regression tests.

## Scope boundary

This is a source/archive cleanup and text correction. It does not claim a physical-device test, APK installation, forensic data removal, performance benchmark or security certification.


No private Cloudflare Worker is shipped by this project. No private API endpoint is claimed.

## Hotfix review

- Added `rebuild-v98.63-hotfix.css` after the previous final layer so the corrections win the cascade without rewriting legacy CSS.
- Confirmed the home keypad retains its original button markup, data-calc values and 4-column/5-row grid; only button footprint, gap and typography are adjusted.
- Expression and preview remain right-aligned, width-constrained and horizontally safe for long input/results.
- Tools and Favorites receive independent vertical scrolling and compact responsive card grids.
- Bottom dock is explicitly flush to the app shell bottom and applies `env(safe-area-inset-bottom)` once.
- Automated verification: 355 tests passed, 0 failed; web bundle regenerated successfully.
- Physical Android device / APK screenshot validation remains outstanding; CSS changes are regression-tested but cannot be certified lag-free on every device from this environment.

## v98.63.5 marked-screen follow-up (2026-11-19)

### Screenshot 1 — currency picker / keyboard
- Root cause addressed: the picker explicitly focused its search input immediately after opening, which could summon the Android IME and obscure the option list.
- Change: picker now focuses its close control instead; users can tap the search field when they actually want to type.
- Option list receives explicit block/grid row layout, full-width sizing, fixed row minimum height, bounded labels and vertical scrolling.

### Screenshot 2 — manual Convert action
- Root cause: a separate `currency-convert-action` button and click listener duplicated the app's live calculation flow.
- Change: removed the button from Currency Converter markup and removed its event listener.
- Preserved: source amount edits, target amount edits, currency pair selection, swap, precision changes, provider refresh and normal recalculation paths still call `calcCurrency()`.
- The Unit Converter and other tools' intentional Calculate/Convert actions are not changed.

### Screenshot 3 — bottom dock / lower gap
- Reworked the app shell and five-tab dock as a consistent flex layout across all destinations.
- Dock reserves the Android bottom safe-area inset once and paints the same dock background through it; touch targets remain outside the system navigation gesture area.
- This is a standards-based inset correction; exact device pixels still require a physical Android screenshot because WebView inset reporting varies by OS/navigation mode.

### Verification
- 364 automated tests passed, 0 failed.
- Android web bundle prepared; 34 required assets verified and 22 CSS layers consolidated.
- JavaScript syntax, YAML syntax, source/production copy equality and ZIP integrity verified.
- Not verified: APK installation on physical device, live provider network behavior, target-device screenshot match or runtime performance benchmark.


## v98.63.9 clean-runtime update

- Production runtime now loads one canonical `assets/css/app.css`; historical source-layer files were removed from the project; the complete production stylesheet is maintained as one canonical file.
- Android web packaging copies the canonical stylesheet directly and no longer rebuilds it by concatenating historical CSS layers.
- 2,272 identical declarations for the same selector/property/value/context were safely deduplicated; declarations with different values or cascade context were retained.
- The generated Android `www/assets/css/` directory contains only `app.css`.
- Physical Android visual verification remains outstanding.
